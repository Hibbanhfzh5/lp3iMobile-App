import { View, Text } from 'react-native';

export default function RegisterScreen(){
    return (
        <View 
          style={{ flex: 1, alignItems: 'center', 
              justifyContent: 'center' 
              }}>
          <Text>Register Screen</Text>
        </View>
      );
}