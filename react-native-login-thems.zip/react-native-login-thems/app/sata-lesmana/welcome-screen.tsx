import { View, Text } from 'react-native';

export default function WelcomeScreen(){
    return (
        <View 
          style={{ flex: 1, alignItems: 'center', 
              justifyContent: 'center' 
              }}>
          <Text>Welcome Screen</Text>
        </View>
      );
}